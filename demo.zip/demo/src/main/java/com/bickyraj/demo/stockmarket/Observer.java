package com.bickyraj.demo.stockmarket;

public interface Observer {
    public void update(Stock stock);
}
