package com.bickyraj.demo.restaurant.foods.momo;

public interface Momo {
    String getName();
    String getDescription();
    double getPrice();
}
