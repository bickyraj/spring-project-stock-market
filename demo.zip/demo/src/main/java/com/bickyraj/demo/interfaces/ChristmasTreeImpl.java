package com.bickyraj.demo.interfaces;

public class ChristmasTreeImpl implements ChristmasTree {
    @Override
    public String decorate() {
        return "Christmas Tree";
    }
}
