package com.bickyraj.demo.appartment;

public abstract class BaseApartment implements IApartment {
}
