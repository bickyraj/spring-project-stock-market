package com.bickyraj.demo.restaurant;

public interface Food {

    String getName();
    String getDescription();
    double getPrice();
}
