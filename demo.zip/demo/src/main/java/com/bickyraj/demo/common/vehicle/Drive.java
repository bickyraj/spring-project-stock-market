package com.bickyraj.demo.common.vehicle;

public interface Drive {
    public void drive();
}
