package com.bickyraj.demo.paymentmethod;

public interface PaymentStrategy {
    public void pay(double amount);
}
