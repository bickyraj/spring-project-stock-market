package com.bickyraj.demo.common.vehicle;

public class SportsVehicle extends Vehicle {
    public SportsVehicle(Drive driveCapability) {
        super(driveCapability);
    }

    public void drive() {
        super.drive();
    }
}
