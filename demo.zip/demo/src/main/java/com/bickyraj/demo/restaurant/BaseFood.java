package com.bickyraj.demo.restaurant;

public abstract class BaseFood implements Food {
}
