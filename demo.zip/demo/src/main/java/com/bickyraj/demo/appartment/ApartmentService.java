package com.bickyraj.demo.appartment;

import java.util.List;

public interface ApartmentService {

    Double getTotalPriceOfApartments(List<Apartment> apartments);
}
