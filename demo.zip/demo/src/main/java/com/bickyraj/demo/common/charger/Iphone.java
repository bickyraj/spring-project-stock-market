package com.bickyraj.demo.common.charger;

public interface Iphone {
    public void onCharge();
}
