package com.bickyraj.demo.stockmarket.application;

import com.bickyraj.demo.stockmarket.infrastructure.kafka.KafkaProducerService;
import com.bickyraj.demo.stockmarket.domain.entity.StockMarketEntity;
import com.bickyraj.demo.stockmarket.domain.repository.StockMarketRepository;
import lombok.*;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class CreateStockUseCase {

    @Getter
    @AllArgsConstructor(staticName = "of")
    @EqualsAndHashCode
    @ToString
    public static class Request {
        private final StockMarketEntity stockMarketEntity;
    }

    @Getter
    @AllArgsConstructor(staticName = "of")
    @EqualsAndHashCode
    @ToString
    public static class Response {
        private final Boolean success;
    }

    private final StockMarketRepository stockMarketRepository;
    private final KafkaProducerService producerService;

    public Response execute(Request request) {
        stockMarketRepository.save(request.stockMarketEntity);
        producerService.sendMessage(request.stockMarketEntity);
        return Response.of(true);
    }
}