package com.bickyraj.demo.pizza;

public interface Pizza {
    String getName();
    double getPrice();
}
