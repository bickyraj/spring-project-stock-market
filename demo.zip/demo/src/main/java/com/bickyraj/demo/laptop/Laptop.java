package com.bickyraj.demo.laptop;

public interface Laptop {
    String getDescription();
    double getPrice();
}
