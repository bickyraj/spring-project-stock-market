package com.bickyraj.demo.common.charger;

public interface Charger {
    void charge();
}
