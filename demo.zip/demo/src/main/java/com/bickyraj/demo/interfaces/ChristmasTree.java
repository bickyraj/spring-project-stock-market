package com.bickyraj.demo.interfaces;

public interface ChristmasTree {
    String decorate();
}
