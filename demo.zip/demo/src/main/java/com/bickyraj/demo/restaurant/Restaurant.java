package com.bickyraj.demo.restaurant;

public interface Restaurant {
    String getName();
    String getAddress();
    String getPhoneNumber();
    FoodCart getFoodCart();
}
