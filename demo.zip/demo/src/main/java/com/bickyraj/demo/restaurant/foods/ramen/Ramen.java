package com.bickyraj.demo.restaurant.foods.ramen;

public interface Ramen {
    String getName();
    String getDescription();
    double getPrice();
}
