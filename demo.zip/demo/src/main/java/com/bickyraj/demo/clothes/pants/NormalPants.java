package com.bickyraj.demo.clothes.pants;

public interface NormalPants {
}
