package com.bickyraj.demo.common.pizza;

public interface Pizza {
    String getDescription();
    double getCost();
}
