package com.bickyraj.demo.clothes.jacket;

public interface Jacket {
    public String getType();
    public double getPrice();
}
